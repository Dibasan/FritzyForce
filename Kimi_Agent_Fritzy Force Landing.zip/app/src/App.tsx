import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import About from './sections/About';
import Profile from './sections/Profile';
import Gallery from './sections/Gallery';
import Connect from './sections/Connect';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-[#1a0a2e] text-white overflow-x-hidden">
      <Navigation />
      <main>
        <Hero />
        <About />
        <Profile />
        <Gallery />
        <Connect />
      </main>
      <Footer />
    </div>
  );
}

export default App;
