import { useEffect, useRef, useState } from 'react';
import { Sparkles, Heart, Users, Target, Zap } from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: Heart,
      title: 'Support',
      description: 'Memberikan dukungan penuh untuk Fritzy dalam setiap aktivitasnya di JKT48',
      color: 'from-pink-500 to-rose-500',
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Menyatukan para penggemar Fritzy dari seluruh Indonesia',
      color: 'from-purple-500 to-violet-500',
    },
    {
      icon: Target,
      title: 'Goals',
      description: 'Membantu Fritzy mencapai impian dan targetnya di dunia entertainment',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Zap,
      title: 'Energy',
      description: 'Menyebarkan energi positif dan semangat untuk Fritzy',
      color: 'from-yellow-500 to-orange-500',
    },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 bg-[#1a0a2e] overflow-hidden"
    >
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">About Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            What is <span className="gradient-text">Fritzy Force</span>?
          </h2>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            Fritzy Force adalah fanbase resmi untuk Fritzy Rosmerian, member JKT48 Generasi 12. 
            Kami adalah komunitas penggemar yang mendukung Fritzy dalam perjalanannya 
            sebagai idol dan pesulap.
          </p>
        </div>

        {/* Tagline */}
        <div
          className={`text-center mb-20 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-purple-500/20 border border-purple-500/30">
            <p className="text-xl sm:text-2xl font-bold gradient-text">
              "Miracle As Eternal Power"
            </p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`group relative p-6 rounded-2xl bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-500 hover:-translate-y-2 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              {/* Icon */}
              <div
                className={`w-14 h-14 rounded-xl bg-gradient-to-r ${feature.color} p-0.5 mb-5 group-hover:scale-110 transition-transform duration-300`}
              >
                <div className="w-full h-full rounded-xl bg-[#1a0a2e] flex items-center justify-center">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>

              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-500/0 to-pink-500/0 group-hover:from-purple-500/10 group-hover:to-pink-500/10 transition-all duration-300 -z-10" />
            </div>
          ))}
        </div>

        {/* Stats */}
        <div
          className={`mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 transition-all duration-1000 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {[
            { value: '12th', label: 'Generation' },
            { value: '2023', label: 'Debut Year' },
            { value: 'TOP 5', label: 'IGT 2022' },
            { value: 'Center', label: 'Position' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl sm:text-4xl font-bold gradient-text mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
