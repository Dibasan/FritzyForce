import { Wand2, Sparkles, Heart, Instagram, Twitter, MessageCircle, Video } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Profile', href: '#profile' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Connect', href: '#connect' },
  ];

  const socialLinks = [
    { icon: Instagram, href: 'https://www.instagram.com/fritzyforce', label: 'Instagram' },
    { icon: Twitter, href: 'https://x.com/FritzyForce', label: 'X (Twitter)' },
    { icon: Video, href: 'https://www.tiktok.com/@fritzyforce', label: 'TikTok' },
    { icon: MessageCircle, href: 'https://www.threads.com/@fritzyforce', label: 'Threads' },
  ];

  return (
    <footer className="relative bg-[#1a0a2e] border-t border-purple-500/20">
      {/* Top gradient line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#home" className="flex items-center gap-2 group mb-6">
              <div className="relative">
                <Wand2 className="w-7 h-7 text-purple-400 group-hover:text-pink-400 transition-colors animate-magic-wand" />
                <Sparkles className="w-4 h-4 text-pink-400 absolute -top-1 -right-1 animate-sparkle" />
              </div>
              <span className="text-2xl font-bold gradient-text">Fritzy Force</span>
            </a>
            <p className="text-gray-400 mb-6 max-w-md">
              Official fanbase of Fritzy Rosmerian, member JKT48 Generation 12. 
              Supporting Fritzy's journey as an idol and magician.
            </p>
            <p className="text-sm text-purple-400 italic mb-6">
              "Miracle As Eternal Power"
            </p>
            
            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-gray-400 hover:text-white hover:bg-purple-500/30 hover:border-purple-500/50 transition-all"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-purple-400 transition-colors flex items-center gap-2 group"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-500/50 group-hover:bg-purple-400 transition-colors" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Official Accounts */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Fritzy's Accounts</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="https://www.instagram.com/jkt48.fritzy.r"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-pink-400 transition-colors flex items-center gap-2"
                >
                  <Instagram className="w-4 h-4" />
                  @jkt48.fritzy.r
                </a>
              </li>
              <li>
                <a
                  href="https://x.com/RFritzy_JKT48"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-blue-400 transition-colors flex items-center gap-2"
                >
                  <Twitter className="w-4 h-4" />
                  @RFritzy_JKT48
                </a>
              </li>
              <li>
                <a
                  href="https://www.tiktok.com/@jkt48.fritzy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-pink-400 transition-colors flex items-center gap-2"
                >
                  <Video className="w-4 h-4" />
                  @jkt48.fritzy
                </a>
              </li>
              <li>
                <a
                  href="https://www.threads.com/@jkt48.fritzy.r"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-purple-400 transition-colors flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  @jkt48.fritzy.r
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-purple-500/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500 text-center md:text-left">
              © {currentYear} Fritzy Force. All rights reserved.
            </p>
            <p className="text-sm text-gray-500 flex items-center gap-1">
              Made with <Heart className="w-4 h-4 text-pink-500 fill-pink-500" /> for Fritzy Rosmerian
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
