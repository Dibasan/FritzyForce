import { useEffect, useRef, useState } from 'react';
import { Sparkles, Camera, Instagram, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog';

const Gallery = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Gallery images with descriptions
  const galleryItems = [
    {
      id: 1,
      title: 'Fritzy JKT48 2025',
      description: 'Official profile photo',
      color: 'from-purple-500 to-pink-500',
      icon: Camera,
    },
    {
      id: 2,
      title: 'Performance',
      description: 'On stage at JKT48 Theater',
      color: 'from-pink-500 to-rose-500',
      icon: Sparkles,
    },
    {
      id: 3,
      title: 'Magic Moment',
      description: 'Showcasing her magic skills',
      color: 'from-violet-500 to-purple-500',
      icon: Sparkles,
    },
    {
      id: 4,
      title: 'Casual Look',
      description: 'Daily life moments',
      color: 'from-blue-500 to-purple-500',
      icon: Camera,
    },
    {
      id: 5,
      title: 'With Fans',
      description: 'Meet and greet session',
      color: 'from-pink-500 to-orange-500',
      icon: Sparkles,
    },
    {
      id: 6,
      title: 'IGT 2022',
      description: 'Indonesia\'s Got Talent',
      color: 'from-yellow-500 to-pink-500',
      icon: Sparkles,
    },
  ];

  return (
    <section
      id="gallery"
      ref={sectionRef}
      className="relative py-24 bg-[#2d1b4e] overflow-hidden"
    >
      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-600/5 rounded-full blur-3xl translate-x-1/3 -translate-y-1/3" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-pink-600/5 rounded-full blur-3xl -translate-x-1/3 translate-y-1/3" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <Camera className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">Gallery</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Fritzy <span className="gradient-text">Moments</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Koleksi momen-momen spesial Fritzy Rosmerian
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <Dialog key={item.id}>
              <DialogTrigger asChild>
                <div
                  className={`group relative aspect-square rounded-2xl overflow-hidden cursor-pointer transition-all duration-500 hover:-translate-y-2 ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                  }`}
                  style={{ transitionDelay: `${200 + index * 100}ms` }}
                >
                  {/* Placeholder gradient background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${item.color} opacity-80`} />
                  
                  {/* Pattern overlay */}
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{
                      backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.3) 1px, transparent 0)`,
                      backgroundSize: '20px 20px'
                    }} />
                  </div>

                  {/* Content */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
                    <item.icon className="w-16 h-16 text-white/60 mb-4 group-hover:scale-110 transition-transform duration-300" />
                    <h3 className="text-xl font-bold text-white text-center">{item.title}</h3>
                    <p className="text-sm text-white/70 text-center mt-2">{item.description}</p>
                  </div>

                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <ExternalLink className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  {/* Border glow */}
                  <div className="absolute inset-0 rounded-2xl border-2 border-white/20 group-hover:border-white/40 transition-colors" />
                </div>
              </DialogTrigger>
              <DialogContent className="max-w-3xl bg-[#1a0a2e] border-purple-500/30">
                <div className={`aspect-video rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center`}>
                  <div className="text-center">
                    <item.icon className="w-24 h-24 text-white/40 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-white">{item.title}</h3>
                    <p className="text-white/70 mt-2">{item.description}</p>
                    <p className="text-sm text-white/50 mt-4">Image placeholder - Visit Instagram for real photos</p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {/* CTA */}
        <div
          className={`text-center mt-12 transition-all duration-1000 delay-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0 shadow-lg shadow-purple-600/30"
          >
            <a
              href="https://www.instagram.com/jkt48.fritzy.r"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2"
            >
              <Instagram className="w-5 h-5" />
              See More on Instagram
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
