import { useEffect, useRef, useState } from 'react';
import {
  Sparkles,
  Instagram,
  Twitter,
  MessageCircle,
  Video,
  Send,
  ExternalLink,
  Heart,
  Hash,
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Connect = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const fritzySocials = [
    {
      name: 'Instagram',
      handle: '@jkt48.fritzy.r',
      url: 'https://www.instagram.com/jkt48.fritzy.r',
      icon: Instagram,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-gradient-to-br from-purple-600 to-pink-600',
      description: 'Official Instagram account',
    },
    {
      name: 'X (Twitter)',
      handle: '@RFritzy_JKT48',
      url: 'https://x.com/RFritzy_JKT48',
      icon: Twitter,
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-gradient-to-br from-blue-500 to-cyan-500',
      description: 'Official X account',
    },
    {
      name: 'TikTok',
      handle: '@jkt48.fritzy',
      url: 'https://www.tiktok.com/@jkt48.fritzy',
      icon: Video,
      color: 'from-pink-500 to-rose-500',
      bgColor: 'bg-gradient-to-br from-pink-500 to-rose-500',
      description: 'Official TikTok account',
    },
    {
      name: 'Threads',
      handle: '@jkt48.fritzy.r',
      url: 'https://www.threads.com/@jkt48.fritzy.r',
      icon: MessageCircle,
      color: 'from-violet-500 to-purple-500',
      bgColor: 'bg-gradient-to-br from-violet-500 to-purple-500',
      description: 'Official Threads account',
    },
  ];

  const fanbaseSocials = [
    {
      name: 'Instagram',
      handle: '@fritzyforce',
      url: 'https://www.instagram.com/fritzyforce',
      icon: Instagram,
      color: 'from-purple-500 to-pink-500',
      description: 'Fritzy Force Instagram',
    },
    {
      name: 'X (Twitter)',
      handle: '@FritzyForce',
      url: 'https://x.com/FritzyForce',
      icon: Twitter,
      color: 'from-blue-500 to-cyan-500',
      description: 'Fritzy Force X',
    },
    {
      name: 'TikTok',
      handle: '@fritzyforce',
      url: 'https://www.tiktok.com/@fritzyforce',
      icon: Video,
      color: 'from-pink-500 to-rose-500',
      description: 'Fritzy Force TikTok',
    },
    {
      name: 'Threads',
      handle: '@fritzyforce',
      url: 'https://www.threads.com/@fritzyforce',
      icon: MessageCircle,
      color: 'from-violet-500 to-purple-500',
      description: 'Fritzy Force Threads',
    },
  ];

  const hashtags = [
    '#betterwithfritzy',
    '#fritzyforce',
    '#fritzyjkt48',
    '#MornZy',
    '#SweetZyDream',
    '#FritzDay',
    '#Zyburan',
    '#FritzCall',
  ];

  return (
    <section
      id="connect"
      ref={sectionRef}
      className="relative py-24 bg-gradient-to-b from-[#2d1b4e] to-[#1a0a2e] overflow-hidden"
    >
      {/* Background decorations */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-600/5 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <Send className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">Connect</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Connect With <span className="gradient-text">Fritzy</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Ikuti Fritzy dan bergabung dengan komunitas Fritzy Force di berbagai platform sosial media
          </p>
        </div>

        {/* Fritzy's Social Media */}
        <div
          className={`mb-16 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-400" />
            Fritzy's Official Accounts
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {fritzySocials.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative p-5 rounded-2xl bg-purple-900/20 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl ${social.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <social.icon className="w-6 h-6 text-white" />
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-500 group-hover:text-purple-400 transition-colors" />
                </div>
                <h4 className="text-lg font-semibold text-white mb-1">{social.name}</h4>
                <p className="text-sm text-purple-400 mb-2">{social.handle}</p>
                <p className="text-xs text-gray-500">{social.description}</p>
              </a>
            ))}
          </div>
        </div>

        {/* Fanbase Social Media */}
        <div
          className={`mb-16 transition-all duration-1000 delay-400 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            Fritzy Force Fanbase
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {fanbaseSocials.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative p-5 rounded-2xl bg-gradient-to-br from-purple-900/30 to-pink-900/30 border border-purple-500/20 hover:border-pink-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${social.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <social.icon className="w-6 h-6 text-white" />
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-500 group-hover:text-pink-400 transition-colors" />
                </div>
                <h4 className="text-lg font-semibold text-white mb-1">{social.name}</h4>
                <p className="text-sm text-pink-400 mb-2">{social.handle}</p>
                <p className="text-xs text-gray-500">{social.description}</p>
              </a>
            ))}
          </div>
        </div>

        {/* Hashtags */}
        <div
          className={`transition-all duration-1000 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Hash className="w-5 h-5 text-yellow-400" />
            Official Hashtags
          </h3>
          <div className="flex flex-wrap gap-3">
            {hashtags.map((hashtag) => (
              <span
                key={hashtag}
                className="px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-sm font-medium hover:bg-purple-500/20 hover:border-purple-500/50 transition-all cursor-default"
              >
                {hashtag}
              </span>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div
          className={`mt-16 text-center transition-all duration-1000 delay-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-block p-8 rounded-3xl bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-purple-600/20 border border-purple-500/30">
            <h3 className="text-2xl font-bold text-white mb-4">
              Join Fritzy Force Today!
            </h3>
            <p className="text-gray-400 mb-6 max-w-md">
              Jadilah bagian dari komunitas penggemar Fritzy. Dukung Fritzy dalam perjalanannya bersama JKT48!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0 shadow-lg shadow-purple-600/30"
              >
                <a
                  href="https://www.instagram.com/fritzyforce"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Instagram className="w-5 h-5" />
                  Follow Fritzy Force
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-purple-500/50 text-purple-200 hover:bg-purple-500/20"
              >
                <a
                  href="https://x.com/FritzyForce"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Twitter className="w-5 h-5" />
                  Follow on X
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Connect;
