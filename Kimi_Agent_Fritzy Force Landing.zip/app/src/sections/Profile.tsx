import { useEffect, useRef, useState } from 'react';
import {
  Sparkles,
  Calendar,
  MapPin,
  Star,
  Droplet,
  Ruler,
  Heart,
  Music,
  Wand2,
  Camera,
  Gamepad2,
  Utensils,
} from 'lucide-react';

const Profile = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const biodata = [
    { icon: Calendar, label: 'Tanggal Lahir', value: '28 Juli 2008' },
    { icon: MapPin, label: 'Asal Kota', value: 'Jakarta' },
    { icon: Star, label: 'Horoskop', value: 'Leo' },
    { icon: Ruler, label: 'Tinggi Badan', value: '157 cm' },
    { icon: Droplet, label: 'Golongan Darah', value: 'A' },
    { icon: Heart, label: 'Status', value: 'Regular Member JKT48' },
  ];

  const hobbies = [
    { icon: Wand2, label: 'Sulap', description: 'Bakat utama sejak usia 6 tahun' },
    { icon: Music, label: 'Menari', description: 'Passion dalam menari' },
    { icon: Camera, label: 'Modeling', description: 'Model sejak usia 4 tahun' },
    { icon: Gamepad2, label: 'Gaming', description: 'Suka bermain Free Fire' },
  ];

  const achievements = [
    'Top 5 Indonesia\'s Got Talent 2022',
    'Best Talent Putri Cilik Indonesia 2019',
    'Tampil di America\'s Got Talent Fantasy League 2024',
    'Original Center Generasi 12 JKT48',
    'Promoted to Regular Member Mei 2025',
  ];

  const favorites = {
    food: 'Seafood & Tomyam',
    dislike: 'Matcha',
    school: 'SMK Global Multimedia (DKV)',
  };

  return (
    <section
      id="profile"
      ref={sectionRef}
      className="relative py-24 bg-gradient-to-b from-[#1a0a2e] to-[#2d1b4e] overflow-hidden"
    >
      {/* Background decorations */}
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-purple-600/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-pink-600/5 rounded-full blur-3xl translate-x-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">Profile</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Meet <span className="gradient-text">Fritzy Rosmerian</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Pesulap cilik yang kini menjadi member JKT48 Generasi 12
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column - Biodata */}
          <div
            className={`transition-all duration-1000 delay-200 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}
          >
            {/* Jikoshoukai Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 mb-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <Wand2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">Jikoshoukai</h3>
                  <p className="text-gray-300 italic">
                    "Abracadabra! Si pesulap yang siap membuat hatimu terpikat. 
                    Halo semuanya, it's me, Fritzy!"
                  </p>
                </div>
              </div>
            </div>

            {/* Biodata Grid */}
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Biodata
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {biodata.map((item) => (
                <div
                  key={item.label}
                  className="flex items-center gap-4 p-4 rounded-xl bg-purple-900/20 border border-purple-500/20 hover:border-purple-500/40 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">{item.label}</p>
                    <p className="text-sm font-semibold text-white">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Favorites */}
            <div className="mt-8 p-6 rounded-2xl bg-pink-900/10 border border-pink-500/20">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Heart className="w-5 h-5 text-pink-400" />
                Favorites
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Utensils className="w-4 h-4 text-pink-400" />
                  <span className="text-sm text-gray-300">
                    <span className="text-gray-500">Makanan Favorit:</span> {favorites.food}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-gray-300">
                    <span className="text-gray-500">Tidak Suka:</span> {favorites.dislike}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-gray-300">
                    <span className="text-gray-500">Pendidikan:</span> {favorites.school}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Hobbies & Achievements */}
          <div
            className={`space-y-8 transition-all duration-1000 delay-400 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}
          >
            {/* Hobbies */}
            <div>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Star className="w-5 h-5 text-pink-400" />
                Hobi & Bakat
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {hobbies.map((hobby) => (
                  <div
                    key={hobby.label}
                    className="p-4 rounded-xl bg-gradient-to-br from-purple-900/30 to-pink-900/30 border border-purple-500/20 hover:border-purple-500/40 transition-all hover:-translate-y-1"
                  >
                    <hobby.icon className="w-8 h-8 text-purple-400 mb-3" />
                    <h4 className="text-lg font-semibold text-white mb-1">{hobby.label}</h4>
                    <p className="text-xs text-gray-400">{hobby.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements */}
            <div>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
                Prestasi
              </h3>
              <div className="space-y-3">
                {achievements.map((achievement, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 rounded-lg bg-purple-900/20 border border-purple-500/20"
                  >
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center flex-shrink-0">
                      <Star className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-sm text-gray-300">{achievement}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Fun Facts */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-600/10 via-pink-600/10 to-purple-600/10 border border-purple-500/20">
              <h3 className="text-lg font-bold text-white mb-4">Fun Facts</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>Fritzy mulai tertarik sulap sejak usia 6 tahun</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>Pernah audition ke SM Entertainment Korea Selatan</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>Debut di JKT48 pada 18 November 2023</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>Fasih berbahasa Inggris</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>Idolanya adalah Okada Nana dan Shiraishi Mai</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Profile;
