import { useEffect, useRef } from 'react';
import { Sparkles, Wand2, Star, Heart, Instagram, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particle system for magical sparkles
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      color: string;
    }> = [];

    const colors = ['#a855f7', '#ec4899', '#8b5cf6', '#f472b6', '#c084fc'];

    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 1,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.5 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((particle) => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;

        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.globalAlpha = particle.opacity;
        ctx.fill();
      });

      ctx.globalAlpha = 1;
      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden magic-gradient"
    >
      {/* Animated background canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
      />

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#1a0a2e]" />
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-transparent to-pink-900/20" />

      {/* Floating decorative elements */}
      <div className="absolute top-20 left-10 animate-float" style={{ animationDelay: '0s' }}>
        <Star className="w-8 h-8 text-purple-400/40" />
      </div>
      <div className="absolute top-40 right-20 animate-float" style={{ animationDelay: '1s' }}>
        <Sparkles className="w-6 h-6 text-pink-400/40" />
      </div>
      <div className="absolute bottom-40 left-20 animate-float" style={{ animationDelay: '2s' }}>
        <Heart className="w-7 h-7 text-purple-400/30" />
      </div>
      <div className="absolute bottom-20 right-10 animate-float" style={{ animationDelay: '1.5s' }}>
        <Wand2 className="w-8 h-8 text-pink-400/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/20 border border-purple-500/30 mb-6">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-sm font-medium text-purple-200">
                Official Fanbase
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold mb-6">
              <span className="text-white">Welcome to</span>
              <br />
              <span className="gradient-text">Fritzy Force</span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-300 mb-4 max-w-2xl">
              The official fanbase of{' '}
              <span className="text-purple-400 font-semibold">Fritzy Rosmerian</span>
              , member of JKT48 Generation 12
            </p>

            <p className="text-base text-gray-400 mb-8 max-w-xl italic">
              "Abracadabra! Si pesulap yang siap membuat hatimu terpikat. 
              Halo semuanya, it's me, Fritzy!"
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0 shadow-lg shadow-purple-600/40 hover:shadow-purple-600/60 transition-all duration-300 group"
              >
                <a href="https://www.instagram.com/jkt48.fritzy.r" target="_blank" rel="noopener noreferrer">
                  <Instagram className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  Follow Fritzy
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-purple-500/50 text-purple-200 hover:bg-purple-500/20 hover:border-purple-400 transition-all duration-300"
              >
                <a href="#about">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Learn More
                </a>
              </Button>
            </div>

            {/* Social stats */}
            <div className="flex flex-wrap gap-6 mt-10 justify-center lg:justify-start">
              <a
                href="https://www.instagram.com/jkt48.fritzy.r"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-purple-400 transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span className="text-sm">@jkt48.fritzy.r</span>
              </a>
              <a
                href="https://x.com/RFritzy_JKT48"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-pink-400 transition-colors"
              >
                <Twitter className="w-5 h-5" />
                <span className="text-sm">@RFritzy_JKT48</span>
              </a>
              <a
                href="https://www.tiktok.com/@jkt48.fritzy"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-purple-400 transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
                <span className="text-sm">@jkt48.fritzy</span>
              </a>
            </div>
          </div>

          {/* Profile Image */}
          <div className="flex-1 relative">
            <div className="relative w-72 h-72 sm:w-96 sm:h-96 mx-auto">
              {/* Glowing ring */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500 animate-pulse-glow blur-xl opacity-60" />
              
              {/* Outer ring */}
              <div className="absolute inset-2 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 p-1">
                <div className="w-full h-full rounded-full bg-[#1a0a2e] flex items-center justify-center overflow-hidden">
                  {/* Placeholder for Fritzy's image */}
                  <div className="w-full h-full bg-gradient-to-br from-purple-400/20 to-pink-400/20 flex items-center justify-center">
                    <div className="text-center">
                      <Wand2 className="w-20 h-20 text-purple-400/50 mx-auto mb-4" />
                      <p className="text-purple-300/70 text-sm">Fritzy Rosmerian</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full p-3 shadow-lg animate-float">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -bottom-2 -left-2 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full p-3 shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                <Star className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-purple-400/50 flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-purple-400 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
